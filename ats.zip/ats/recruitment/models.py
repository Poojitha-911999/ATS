from django.db import models
from django.contrib.auth.models import User

class Employer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    company_name = models.CharField(max_length=255)

class JobPost(models.Model):
    employer = models.ForeignKey(Employer, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    salary = models.CharField(max_length=255)
    responsibilities = models.TextField()
    r1_questions = models.JSONField(default=list)

class Candidate(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    resume = models.FileField(upload_to='resumes/')

class Application(models.Model):
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE)
    job_post = models.ForeignKey(JobPost, on_delete=models.CASCADE)
    r1_answers = models.JSONField(default=dict)
    r2_answers = models.JSONField(default=dict)
    shortlisted = models.BooleanField(default=False)

class Coordinator(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    assigned_jobs = models.ManyToManyField(JobPost, related_name='coordinated_jobs')

class Recruiter(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    assigned_applications = models.ManyToManyField(Application, related_name='recruiter_applications')
    r2_questions = models.JSONField(default=list)
