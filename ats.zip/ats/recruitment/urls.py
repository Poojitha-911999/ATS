from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('candidate_dashboard/', views.candidate_dashboard, name='candidate_dashboard'),
    path('coordinator_dashboard/', views.coordinator_dashboard, name='coordinator_dashboard'),
    path('recruiter_dashboard/', views.recruiter_dashboard, name='recruiter_dashboard'),
    path('job/<int:pk>/', views.job_post_detail, name='job_post_detail'),
    path('application/<int:pk>/review/', views.review_application, name='review_application'),
    path('job/<int:pk>/assign_recruiters/', views.assign_recruiters, name='assign_recruiters'),
    path('job/create/', views.create_job_post, name='create_job_post'),
    path('job/<int:pk>/edit/', views.edit_job_post, name='edit_job_post'),
    path('job/<int:pk>/delete/', views.delete_job_post, name='delete_job_post'),
]
