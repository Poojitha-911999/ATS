from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Employer, Candidate, Coordinator, Recruiter

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    role = forms.ChoiceField(choices=[('candidate', 'Candidate'), ('employer', 'Employer'), ('coordinator', 'Coordinator'), ('recruiter', 'Recruiter')])

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'role']

    def save(self, commit=True):
        user = super(UserRegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        role = self.cleaned_data['role']
        if role == 'employer':
            Employer.objects.create(user=user)
        elif role == 'candidate':
            Candidate.objects.create(user=user)
        elif role == 'coordinator':
            Coordinator.objects.create(user=user)
        elif role == 'recruiter':
            Recruiter.objects.create(user=user)
        return user
