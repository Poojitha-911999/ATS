from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from .forms import UserRegistrationForm
from .models import JobPost, Application

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserRegistrationForm()
    return render(request, 'recruitment/register.html', {'form': form})

def dashboard(request):
    user = request.user
    if hasattr(user, 'employer'):
        jobs = JobPost.objects.filter(employer=user.employer)
        return render(request, 'recruitment/employer_dashboard.html', {'jobs': jobs})
    elif hasattr(user, 'candidate'):
        jobs = JobPost.objects.all()
        return render(request, 'recruitment/candidate_dashboard.html', {'jobs': jobs})
    elif hasattr(user, 'coordinator'):
        jobs = JobPost.objects.all()
        return render(request, 'recruitment/coordinator_dashboard.html', {'jobs': jobs})
    elif hasattr(user, 'recruiter'):
        applications = Application.objects.all()
        return render(request, 'recruitment/recruiter_dashboard.html', {'applications': applications})
    return render(request, 'recruitment/dashboard.html')
